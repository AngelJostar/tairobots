<?php
  $activeSite = $state['sites'][0] ?? null;
  $siteZones = $activeSite ? collect($state['zones'])->where('siteId', $activeSite['id'])->values() : collect();
  $siteRobots = $activeSite ? collect($state['robots'])->where('siteId', $activeSite['id'])->values() : collect();
  $kindLabel = ['restricted' => 'Zona restringida', 'work' => 'Área de trabajo', 'charging' => 'Estación de carga', 'poi' => 'Punto de interés'];
?>
<section class="maps-dashboard">
  <header class="maps-heading"><div><p class="eyebrow">GESTIÓN DE ROBOTS</p><h1>Un contexto para cada movimiento.</h1><p>Planos locales por sede. Coordenadas en metros.</p></div><button class="btn primary" data-open="new-zone">＋ Nueva zona</button></header>
  <div class="summary-tabs"><span class="active">Tu espacio</span><span><?php echo e($client->name); ?> · <?php echo e($activeSite['name'] ?? 'Sin sede'); ?></span><a>⌕　Filtrar　<?php echo e($siteZones->count()); ?></a></div>
  <?php if($activeSite): ?>
    <section class="maps-card">
      <header><div><h2><?php echo e($activeSite['name']); ?></h2><p><?php echo e($activeSite['building']); ?> · <?php echo e($activeSite['floor']); ?> · <?php echo e($activeSite['width'] ?? 100); ?> × <?php echo e($activeSite['height'] ?? 70); ?> m</p></div><small>♧　 Coordenadas locales</small></header>
      <div class="maps-canvas">
        <span class="map-label">●　Plano de simulación　· <?php echo e($activeSite['floor']); ?></span><span class="map-north">N local<br>▲</span>
        <?php $__currentLoopData = $siteZones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="maps-zone <?php echo e($zone['kind']); ?>" style="left:<?php echo e($zone['x']); ?>%;top:<?php echo e($zone['y'] / ($activeSite['height'] ?? 70) * 100); ?>%;width:<?php echo e($zone['w']); ?>%;height:<?php echo e($zone['h'] / ($activeSite['height'] ?? 70) * 100); ?>%"><span><?php echo e($zone['name']); ?></span></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="summary-route"></div>
        <?php $__currentLoopData = $siteRobots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="maps-robot" style="left:<?php echo e($robot['x']); ?>%;top:<?php echo e($robot['y'] / ($activeSite['height'] ?? 70) * 100); ?>%" title="<?php echo e($robot['name']); ?>">▲<small><?php echo e($robot['name']); ?></small></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="map-legend">●　Robot　 ┄ ┄　Ruta de referencia</div><small class="map-scale">10 m ───</small><small class="map-frame"><?php echo e($activeSite['frame']); ?></small>
      </div>
    </section>
    <p class="maps-note">◉　 Este plano ilustra un entorno simulado. Las posiciones usan <b><?php echo e($activeSite['frame']); ?></b> con unidades en metros. No existe una transformación a GPS; cartografía exterior y navegación física quedan para la integración real.</p>
    <div class="map-zone-cards"><?php $__empty_1 = true; $__currentLoopData = $siteZones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><article class="<?php echo e($zone['kind']); ?>"><i><?php echo e($zone['kind'] === 'charging' ? '⌾' : ($zone['kind'] === 'restricted' ? '⌖' : '◫')); ?></i><div><h3><?php echo e($zone['name']); ?></h3><p><?php echo e($kindLabel[$zone['kind']] ?? $zone['kind']); ?></p><small><?php echo e($zone['x']); ?> m · <?php echo e($zone['y']); ?> m · <?php echo e($zone['w']); ?> × <?php echo e($zone['h']); ?> m</small><?php if(!collect($state['resources'])->contains('id', $zone['id'])): ?><?php echo $__env->make('partials.action',['operation'=>'zone.delete','data'=>['id'=>$zone['id']],'button'=>'Eliminar zona','confirm'=>'¿Eliminar esta zona?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?></div></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="empty">Todavía no hay zonas configuradas.</p><?php endif; ?></div>
  <?php else: ?>
    <section class="mission-empty"><i>⌑</i><h3>No hay una sede seleccionada</h3><p>Crea una sede para visualizar y configurar su plano local.</p></section>
  <?php endif; ?>
</section>
<?php /**PATH C:\laragon\www\tairobots\resources\views\management\zonas.blade.php ENDPATH**/ ?>