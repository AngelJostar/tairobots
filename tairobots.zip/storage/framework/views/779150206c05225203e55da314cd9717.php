<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$name=$field['name'];$type=$field['type'];$value=$field['value'];$dot=trim(str_replace(['[',']'],['.',''],$name),'.');
if(isset($restore)&&$restore){$value=old($dot,$value);}
?>
<?php if($type==='hidden'): ?><input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
<?php elseif($type==='checkbox'): ?><label class="field check"><input type="hidden" name="<?php echo e($name); ?>" value="0"><input type="checkbox" name="<?php echo e($name); ?>" value="1" <?php if($value): echo 'checked'; endif; ?>><?php echo e($field['label']); ?></label>
<?php else: ?><label class="<?php echo \Illuminate\Support\Arr::toCssClasses(['field','wide'=>in_array($type,['textarea','multiple'])]); ?>"><?php echo e($field['label']); ?>

<?php if(in_array($type,['select','multiple'])): ?><select name="<?php echo e($name); ?><?php echo e($type==='multiple'?'[]':''); ?>" <?php if($type==='multiple'): ?> multiple <?php endif; ?> <?php if($field['required']): echo 'required'; endif; ?>><?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>" <?php if($type==='multiple'?in_array((string)$key,array_map('strval',(array)$value)):(string)$key===(string)$value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php if($type==='multiple'): ?><small class="muted">Puedes seleccionar varias opciones con Ctrl o ⌘.</small><?php endif; ?>
<?php elseif($type==='textarea'): ?><textarea name="<?php echo e($name); ?>" maxlength="5000" <?php if($field['required']): echo 'required'; endif; ?>><?php echo e($value); ?></textarea>
<?php else: ?><input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" <?php if($type!=='file'): ?> value="<?php echo e($value); ?>" <?php endif; ?> <?php if($type==='number'): ?> step="any" min="0" <?php endif; ?> <?php if($type==='text'): ?> maxlength="200" <?php endif; ?> <?php if($field['required']): echo 'required'; endif; ?>>
<?php endif; ?></label><?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\tairobots\resources\views\partials\fields.blade.php ENDPATH**/ ?>