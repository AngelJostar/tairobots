<section class="clients-dashboard" aria-label="Clientes y sedes">
  <header class="clients-heading">
    <div><p class="eyebrow">GESTIÓN DE ROBOTS</p><h1>Una operación, múltiples entornos.</h1><p>Organiza clientes, sedes y espacios de trabajo.</p></div>
    <div class="clients-actions"><a href="<?php echo e($url('robots')); ?>">Filtrar　⌄</a></div>
  </header>
  <div class="summary-tabs clients-tabs"><span class="active">Tu espacio</span><span>Todos los clientes</span></div>

  <div class="client-card-list">
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $clientState = $item->state;
        $clientRobots = collect($clientState['robots'] ?? []);
        $clientSites = collect($clientState['sites'] ?? []);
        $fleetCount = $clientRobots->pluck('fleet')->filter()->unique()->count();
        $clientUrl = route('management', ['tab' => 'clientes', 'client' => $item->id]);
      ?>
      <article class="client-summary-card" <?php if($client->id === $item->id): ?> id="cliente-activo" <?php endif; ?>>
        <header><span class="client-symbol"><?php echo e($loop->first ? '＋' : '♧'); ?></span><div><h2><?php echo e($item->name); ?></h2><p><?php echo e($clientState['industry'] ?? 'Operación conectada'); ?></p></div><small>DEMO</small></header>
        <div class="client-summary-metrics"><div><b><?php echo e($clientSites->count()); ?></b><span>sedes</span></div><div><b><?php echo e($clientRobots->count()); ?></b><span>robots</span></div><div><b><?php echo e($fleetCount); ?></b><span>flotas</span></div></div>
        <div class="client-sites">
          <?php $__empty_1 = true; $__currentLoopData = $clientSites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $siteRobots = $clientRobots->where('siteId', $site['id']); ?>
            <a href="<?php echo e(route('management', ['tab' => 'operacion', 'client' => $item->id])); ?>"><i>♙</i><span><b><?php echo e($site['name']); ?></b><small><?php echo e($site['building']); ?> · <?php echo e($site['floor']); ?></small><em><?php echo e($site['environment']); ?> · <?php echo e($siteRobots->count()); ?> robots</em></span><strong>↗</strong></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">Aún no hay sedes configuradas.</p>
          <?php endif; ?>
        </div>
        <footer>▱　Cliente → sede → edificio / piso → flota → robot</footer>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>

<?php echo $__env->make('partials.dialog',['dialogId'=>'new-site','title'=>'Nueva sede','operation'=>'site','fields'=>$forms['site']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\laragon\www\tairobots\resources\views\management\clientes.blade.php ENDPATH**/ ?>