<?php
  $siteNames = collect($state['sites'])->pluck('name', 'id');
  $robotSymbols = ['humanoid' => '♙', 'drone' => '✦', 'quadruped' => '⌁', 'amr' => '▰', 'arm' => '⚙', 'service' => '◉', 'cleaner' => '◌'];
  $fleets = collect($state['robots'])->pluck('fleet')->filter()->unique()->values();
?>
<section class="robots-dashboard" aria-label="Robots y flotas">
  <header class="robots-heading"><div><p class="eyebrow">GESTIÓN DE ROBOTS</p><h1>Cada robot, en su lugar.</h1><p>Conoce las capacidades y el estado de todos tus equipos.</p></div><a class="btn primary" data-open="new-robot">＋ Nuevo robot</a></header>
  <div class="summary-tabs robots-tabs"><span class="active">Tu espacio</span><span>Todos los clientes</span><a href="#robots-grid">Filtrar　⌄</a></div>
  <div class="robots-toolbar"><label class="robots-search">⌕<input type="search" data-filter placeholder="Buscar por nombre, modelo o serie…" aria-label="Buscar robots"></label><select data-robot-fleet><option value="">Todas las flotas</option><?php $__currentLoopData = $fleets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fleet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($fleet); ?>"><?php echo e($fleet); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><span><?php echo e(count($state['robots'])); ?> robots</span><b>▦　☷　♧</b></div>
  <div class="robots-showcase-grid" id="robots-grid">
    <?php $__empty_1 = true; $__currentLoopData = $state['robots']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article class="robot-showcase" data-open="robot-detail-<?php echo e($robot['id']); ?>" data-search="<?php echo e(strtolower($robot['name'].' '.$robot['serial'].' '.$robot['fleet'].' '.($labels['typeLabels'][$robot['type']] ?? ''))); ?>" data-fleet="<?php echo e($robot['fleet']); ?>" tabindex="0" role="button" aria-label="Ver detalle de <?php echo e($robot['name']); ?>">
        <header><span class="summary-status <?php echo e($robot['status']); ?>">• <?php echo e($badge($robot['status'])); ?></span><b>↗</b></header>
        <div class="robot-portrait type-<?php echo e($robot['type']); ?>"><i><?php echo e($robotSymbols[$robot['type']] ?? '◉'); ?></i><small>SIM</small></div>
        <div class="robot-showcase-name"><h2><?php echo e($robot['name']); ?></h2><span><?php echo e($labels['typeLabels'][$robot['type']] ?? $robot['type']); ?></span></div>
        <p>⌾　<?php echo e($siteNames[$robot['siteId']] ?? 'Sin sede'); ?></p>
        <footer><span>▱ <?php echo e(round($robot['battery'])); ?>%</span><span><?php echo e(count($robot['capabilities'])); ?> capacidades</span></footer>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="empty">Todavía no hay robots. Registra uno para comenzar.</p>
    <?php endif; ?>
  </div>
  <?php $__currentLoopData = $state['robots']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $robotSite = $siteNames[$robot['siteId']] ?? 'Sin sede'; ?>
    <dialog class="dialog robot-detail-dialog" id="robot-detail-<?php echo e($robot['id']); ?>" aria-labelledby="robot-detail-title-<?php echo e($robot['id']); ?>">
      <header class="dialog-head"><div><p class="eyebrow">TAIROBOTS · SIMULACIÓN</p><h2 id="robot-detail-title-<?php echo e($robot['id']); ?>"><?php echo e($robot['name']); ?></h2></div><button type="button" class="close" data-close aria-label="Cerrar">×</button></header>
      <div class="robot-detail-body">
        <section class="robot-detail-intro"><div class="robot-detail-portrait type-<?php echo e($robot['type']); ?>"><?php echo e($robotSymbols[$robot['type']] ?? '◉'); ?></div><div><span class="summary-status <?php echo e($robot['status']); ?>">• <?php echo e($badge($robot['status'])); ?></span><h3><?php echo e($robot['name']); ?></h3><p><?php echo e($labels['typeLabels'][$robot['type']] ?? $robot['type']); ?> · <?php echo e($robot['manufacturer']); ?></p><small>DATOS SIMULADOS</small></div></section>
        <dl class="robot-detail-grid">
          <div><dt>Serie</dt><dd><?php echo e($robot['serial']); ?></dd></div><div><dt>Modelo</dt><dd><?php echo e($robot['model']); ?></dd></div><div><dt>Software</dt><dd><?php echo e($robot['software'] ?? 'sim/1.0'); ?></dd></div>
          <div><dt>Cliente</dt><dd><?php echo e($client->name); ?></dd></div><div><dt>Sede</dt><dd><?php echo e($robotSite); ?></dd></div><div><dt>Flota</dt><dd><?php echo e($robot['fleet']); ?></dd></div>
          <div><dt>Responsable</dt><dd><?php echo e($robot['responsible']); ?></dd></div><div><dt>Propietario</dt><dd><?php echo e($client->name); ?></dd></div><div><dt>Batería</dt><dd><?php echo e(round($robot['battery'])); ?>% · simulada</dd></div>
          <div><dt>Velocidad de referencia</dt><dd><?php echo e($robot['limits']['speed']); ?> m/s · declarada</dd></div><div><dt>Próximo mantenimiento</dt><dd><?php echo e(date('d M Y', $robot['maintenanceDue'] / 1000)); ?></dd></div><div><dt>Referencia</dt><dd><?php echo e($robotSite); ?></dd></div>
          <div><dt>Integración</dt><dd>NEXO Simulator · sim/1.0</dd></div>
        </dl>
        <section class="robot-capabilities"><h3>Capacidades declaradas</h3><div><?php $__currentLoopData = $robot['capabilities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span><?php echo e($labels['capabilityLabels'][$capability] ?? $capability); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section>
        <footer class="robot-detail-actions"><a class="btn primary" href="<?php echo e($url('operacion')); ?>">◉　Centro de operaciones</a><a class="btn" href="<?php echo e($url('mantenimiento')); ?>">⌕　Mantenimiento</a><a class="btn" href="<?php echo e($url('clientes')); ?>">Reasignar cliente</a></footer>
      </div>
    </dialog>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php echo $__env->make('partials.dialog',['dialogId'=>'new-robot','title'=>'Nuevo robot','operation'=>'robot','fields'=>$forms['robot']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\laragon\www\tairobots\resources\views\management\robots.blade.php ENDPATH**/ ?>