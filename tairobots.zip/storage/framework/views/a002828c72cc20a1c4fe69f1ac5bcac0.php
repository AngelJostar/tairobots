<?php
  $robots = collect($state['robots']);
  $available = $robots->where('status', 'available')->count();
  $activeMissions = collect($state['missions'])->whereIn('status', \App\Services\Robotics::ACTIVE);
  $openAlerts = collect($state['alerts'])->where('status', '!=', 'resolved');
  $sitesById = collect($state['sites'])->keyBy('id');
  $typeSymbol = ['humanoid' => '♙', 'drone' => '✦', 'quadruped' => '⌁', 'amr' => '▰', 'arm' => '⚙', 'service' => '◉', 'cleaner' => '◌'];
?>

<section class="summary-dashboard" aria-label="Resumen de la operación">
  <header class="summary-heading">
    <div><p class="eyebrow">GESTIÓN DE ROBOTS</p><h1>Tu operación, en armonía.</h1><p>Todo lo que necesitas para coordinar tu flota.</p></div>
    <div class="summary-actions"><a class="btn primary" href="<?php echo e($url('misiones')); ?>">＋ Nueva misión</a><button class="btn" data-pulse="<?php echo e(route('management.pulse')); ?>">Actualizar simulación ↻</button></div>
  </header>
  <div class="summary-tabs"><span class="active">Tu espacio</span><span>Todos los clientes</span><a href="<?php echo e($url('robots')); ?>">Filtrar ⌄</a></div>
  <section class="summary-hero">
    <div><p>UNA FLOTA. UN SOLO ESPACIO.</p><h2>Menos pasos.<br>Más posibilidades.</h2><span>Asigna una misión. Elige tu robot.<br>Sigue cada resultado desde aquí.</span><a href="<?php echo e($url('misiones')); ?>">Explorar misiones <b>→</b></a></div>
    <div class="summary-hero-art" aria-hidden="true"><i class="orbit orbit-one"></i><i class="orbit orbit-two"></i><div class="summary-bot">●</div><div class="summary-rover"><b></b><i></i><i></i></div><small>● Coordinados desde Tairobots</small></div>
  </section>
  <section class="summary-stats" aria-label="Indicadores">
    <article><span>Robots en tu flota</span><b class="stat-icon">♙</b><strong><?php echo e(str_pad((string) $robots->count(), 2, '0', STR_PAD_LEFT)); ?></strong><small>• <?php echo e($robots->count()); ?> conectados</small></article>
    <article><span>Disponibles</span><b class="stat-icon ok">✓</b><strong><?php echo e(str_pad((string) $available, 2, '0', STR_PAD_LEFT)); ?></strong><small>• Listos para una nueva tarea</small></article>
    <article><span>Misiones activas</span><b class="stat-icon info">➤</b><strong><?php echo e(str_pad((string) $activeMissions->count(), 2, '0', STR_PAD_LEFT)); ?></strong><small>• <?php echo e($activeMissions->count()); ?> por iniciar</small></article>
    <article><span>Alertas abiertas</span><b class="stat-icon warn">△</b><strong><?php echo e(str_pad((string) $openAlerts->count(), 2, '0', STR_PAD_LEFT)); ?></strong><small>• Tu operación está al día</small></article>
  </section>
  <section class="summary-card summary-map-card">
    <header><div><h2>Vista de operaciones <small>EN VIVO · SIM</small></h2><p>Tu flota, ubicada en su entorno.</p></div><form method="get" action="<?php echo e(route('management')); ?>"><input type="hidden" name="tab" value="resumen"><select name="client" onchange="this.form.submit()"><?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item->id); ?>" <?php if($client->id===$item->id): echo 'selected'; endif; ?>><?php echo e($item->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></form></header>
    <div class="summary-map"><span class="map-label">● Plano de simulación · <?php echo e($state['sites'][0]['floor'] ?? 'Planta baja'); ?></span><?php $__currentLoopData = $state['zones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="summary-zone <?php echo e($zone['kind']); ?>" style="left:<?php echo e($zone['x']); ?>%;top:<?php echo e($zone['y'] / 70 * 100); ?>%;width:<?php echo e($zone['w']); ?>%;height:<?php echo e($zone['h'] / 70 * 100); ?>%"><?php echo e($zone['name']); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><div class="summary-route"></div><?php $__currentLoopData = $robots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="summary-map-robot" style="left:<?php echo e($robot['x']); ?>%;top:<?php echo e($robot['y'] / 70 * 100); ?>%" title="<?php echo e($robot['name']); ?>"><?php echo e(strtoupper(substr($robot['name'], 0, 1))); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><div class="map-legend">● Robot　 ┄ ┄ Ruta de referencia</div></div>
    <footer><a href="<?php echo e($url('operacion')); ?>">Abrir centro de operaciones　↗</a></footer>
  </section>
  <section class="summary-card summary-missions">
    <header><h2>Misiones activas <small><?php echo e($activeMissions->count()); ?></small></h2><a href="<?php echo e($url('misiones')); ?>">↗</a></header>
    <?php if($activeMissions->isEmpty()): ?><div class="summary-empty"><b>➤</b><h3>Tu siguiente misión empieza aquí</h3><p>Asigna una tarea compatible y observa su ejecución.</p><a class="btn" href="<?php echo e($url('misiones')); ?>">＋ Crear misión</a></div><?php else: ?><div class="summary-mission-list"><?php $__currentLoopData = $activeMissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($url('misiones')); ?>"><?php echo e($mission['name']); ?> <span><?php echo e($badge($mission['status'])); ?></span> ↗</a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
    <footer><a href="<?php echo e($url('misiones')); ?>">Ver todas las misiones　→</a></footer>
  </section>
  <section class="summary-card summary-fleet">
    <header><h2>Estado de la flota <small><?php echo e($robots->count()); ?></small></h2><a href="<?php echo e($url('robots')); ?>">Ver todos　→</a></header>
    <div class="summary-fleet-head"><span>Robot</span><span>Estado</span><span>Ubicación</span><span>Batería</span><span>Última señal</span><span></span></div>
    <?php $__empty_1 = true; $__currentLoopData = $robots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $robot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><a class="summary-robot-row" href="<?php echo e($url('robots')); ?>"><span class="summary-robot-name"><i><?php echo e($typeSymbol[$robot['type']] ?? '◉'); ?></i><b><?php echo e($robot['name']); ?><small><?php echo e($labels['typeLabels'][$robot['type']] ?? $robot['type']); ?></small></b></span><span class="summary-status <?php echo e($robot['status']); ?>">• <?php echo e($badge($robot['status'])); ?></span><span><?php echo e($sitesById[$robot['siteId']]['name'] ?? '—'); ?><small><?php echo e($robot['area'] ?? $robot['fleet']); ?></small></span><span>▱ <?php echo e(round($robot['battery'])); ?>%</span><span>• 0 s</span><b>↗</b></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="empty">Aún no hay robots registrados.</p><?php endif; ?>
    <footer>En misión　<?php echo e($robots->whereIn('status', ['busy','running'])->count()); ?>　 Cargando　<?php echo e($robots->where('status','charging')->count()); ?>　 Desconectado　<?php echo e($robots->where('status','offline')->count()); ?></footer>
  </section>
  <section class="summary-card summary-activity">
    <header><h2>Actividad reciente</h2><span>◷</span></header>
    <div><?php $__empty_1 = true; $__currentLoopData = array_slice(array_reverse($state['events']), 0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><article><b>⌁</b><p><?php echo e($event['detail']); ?><small><?php echo e($event['actor']); ?> · <?php echo e(date('H:i', $event['at'] / 1000)); ?></small></p></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="empty">Aún no hay actividad reciente.</p><?php endif; ?></div>
    <footer><a href="<?php echo e($url('auditoria')); ?>">Consultar auditoría　→</a></footer>
  </section>
</section>
<?php /**PATH C:\laragon\www\tairobots\resources\views\management\resumen.blade.php ENDPATH**/ ?>