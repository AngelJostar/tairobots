<?php
  $alerts = collect($state['alerts'] ?? [])->sortByDesc('createdAt')->values();
  $openAlerts = $alerts->where('status', 'open')->count();
?>
<section class="alerts-dashboard">
  <header class="alerts-heading"><div><p class="eyebrow">GESTIÓN DE ROBOTS</p><h1>Atención donde hace falta.</h1><p>Revisa, asigna y documenta cada incidente.</p></div></header>
  <div class="summary-tabs alerts-tabs"><span class="active">Tu espacio</span><span><?php echo e($client->name); ?> · <?php echo e($state['sites'][0]['name'] ?? 'Sin sede'); ?></span><a>⌕　Filtrar　<?php echo e($alerts->count()); ?></a></div>
  <section class="incident-panel">
    <header><h2>Incidentes <small><?php echo e($openAlerts); ?></small></h2><nav><a>Abiertas</a><a>En atención</a><a>Resueltas</a></nav></header>
    <?php $__empty_1 = true; $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article class="incident-row">
        <i>!</i><div><span class="summary-status <?php echo e($alert['severity']); ?>"><?php echo e($badge($alert['severity'])); ?></span><h3><?php echo e($alert['title']); ?></h3><p><?php echo e($robotOptions[$alert['robotId']] ?? '—'); ?> · <?php echo e($siteOptions[$alert['siteId']] ?? '—'); ?> · Responsable: <?php echo e($alert['owner']); ?></p></div><button class="btn" data-open="alert-<?php echo e($alert['id']); ?>">Atender　→</button>
      </article>
      <?php echo $__env->make('partials.dialog',['dialogId'=>'alert-'.$alert['id'],'title'=>'Atender alerta','operation'=>'alert','fields'=>[$hidden('id',$alert['id']),$f('status','Estado','select',$alert['status'],['open'=>'Abierta','acknowledged'=>'En atención','resolved'=>'Resuelta']),$f('comment','Comentario / resolución','textarea')]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="incident-empty"><i>♢</i><h3>Todo en orden</h3><p>No hay incidentes registrados. Prueba una desconexión, una falla o batería baja desde los escenarios.</p><button class="btn" data-open="simulation-scenario">Probar escenario</button></div>
    <?php endif; ?>
  </section>
</section>
<?php /**PATH C:\laragon\www\tairobots\resources\views\management\alertas.blade.php ENDPATH**/ ?>